print("Hello from Lua 2.2")
